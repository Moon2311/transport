from django.db import models
from django.contrib.auth.models import User



class Vehicle(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='vehicle')
    v_name = models.CharField(max_length=100, db_column='name')
    v_model = models.CharField(max_length=100, db_column='model')
    v_number = models.CharField(max_length=100, db_column='v_number',unique=True)

    def __str__(self):
        return f'Vehicle {self.v_name} ({self.v_model}) - Owned by {self.user.username}'
