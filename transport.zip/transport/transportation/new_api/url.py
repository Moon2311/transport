from django.urls import path
from .views import UserRegistrationView, UserLoginView, VehicleCRUDView

urlpatterns = [
    path('register/', UserRegistrationView.as_view(), name='user-register'),
    path('login/', UserLoginView.as_view(), name='user-login'),
    path('vehicle/', VehicleCRUDView.as_view(), name='vehicle-crud'),
]
