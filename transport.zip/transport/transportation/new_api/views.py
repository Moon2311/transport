from django.core.serializers import serialize
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from .serializers import( UserRegistrationSerializer,VehicleSerializer)
from .models import User,Vehicle
from django.contrib.auth.models import User


class UserRegistrationView(APIView):
    def post(self,request, *args, **kwargs):
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user=serializer.save()
            return Response({
                'message':'User Register successfully',
                'User' : {
                    'username':user.username,
                    'email':user.email

            }
            },status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class UserLoginView(APIView):
    def post(self, request, *args, **kwargs):

        username = request.data.get("username")
        password = request.data.get("password")

        if not username or not password:
            return Response({"error": "Username and password are required"}, status=status.HTTP_400_BAD_REQUEST)

        user = authenticate(request, username=username, password=password)

        if user:
            refresh = RefreshToken.for_user(user)
            response_data = {
                'Access_token': str(refresh.access_token),
                'Refresh_token': str(refresh),
                'user_id': user.id,
                'username': user.username
            }
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response({'error': 'Invalid username or password'}, status=status.HTTP_401_UNAUTHORIZED)


class VehicleCRUDView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            vehicle = Vehicle.objects.get(user=request.user)
            serializer = VehicleSerializer(vehicle)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Vehicle.DoesNotExist:
            return Response({'detail': 'Vehicle not found for this user'}, status=status.HTTP_404_NOT_FOUND)

    def post(self, request):

        if Vehicle.objects.filter(user=request.user).exists():
            return Response({'detail': 'This user already has a vehicle assigned.'}, status=status.HTTP_400_BAD_REQUEST)

        request.data['user'] = request.user.id
        serializer = VehicleSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        try:
            vehicle = Vehicle.objects.get(user=request.user)
        except Vehicle.DoesNotExist:
            return Response({'detail': 'Vehicle not found for this user'}, status=status.HTTP_404_NOT_FOUND)

        serializer = VehicleSerializer(vehicle, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):

        try:
            vehicle = Vehicle.objects.get(user=request.user)
            vehicle.delete()
            return Response({'detail': 'Vehicle deleted successfully'}, status=status.HTTP_204_NO_CONTENT)
        except Vehicle.DoesNotExist:
            return Response({'detail': 'Vehicle not found for this user'}, status=status.HTTP_404_NOT_FOUND)



