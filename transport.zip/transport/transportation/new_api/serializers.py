from rest_framework import serializers
from .models import User,Vehicle
from django.contrib.auth.models import User


class UserRegistrationSerializer(serializers.ModelSerializer):
    password =serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields=['username','email','password']

    def create(self,validated_data):
        user=User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password']
        )
        return user

class VehicleSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())

    class Meta:
        model = Vehicle
        fields = ['id', 'user', 'v_name', 'v_model', 'v_number']

    def validate_v_number(self, value):
        if Vehicle.objects.filter(v_number=value).exists():
            raise serializers.ValidationError("This vehicle number is already assigned to another vehicle.")
        return value

    def validate(self, data):
        if Vehicle.objects.filter(user=data['user']).exists():
            raise serializers.ValidationError("This user already has a vehicle assigned.")
        return data
